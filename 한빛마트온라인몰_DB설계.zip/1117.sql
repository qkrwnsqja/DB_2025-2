-- 제조업체 (부모)
CREATE TABLE MANUFACTURER (
    manufacturer_name VARCHAR2(30) NOT NULL,
    phone             VARCHAR2(20) NOT NULL,
    location          VARCHAR2(100),
    manager           VARCHAR2(20),
    CONSTRAINT PK_MANUFACTURER PRIMARY KEY (manufacturer_name)
);
/

-- 회원
CREATE TABLE MEMBER_TB (
    member_id  VARCHAR2(20) NOT NULL,
    password   VARCHAR2(20) NOT NULL,
    name       VARCHAR2(20) NOT NULL,
    age        NUMBER(3),
    job        VARCHAR2(20),
    grade      VARCHAR2(20) DEFAULT 'Silver' NOT NULL,
    mileage    NUMBER DEFAULT 0 NOT NULL,
    CONSTRAINT PK_MEMBER PRIMARY KEY (member_id),
    CONSTRAINT CHK_MEMBER_AGE CHECK (age IS NULL OR age >= 0),
    CONSTRAINT CHK_MEMBER_GRADE CHECK (grade IN ('Silver','gold','vip')),
    CONSTRAINT CHK_MEMBER_MILEAGE CHECK (mileage >= 0)
);
/

-- 상품 (참조: MANUFACTURER)
CREATE TABLE PRODUCT_TB (
    product_id        VARCHAR2(20) NOT NULL,
    product_name      VARCHAR2(50) NOT NULL,
    stock             NUMBER DEFAULT 0 NOT NULL,
    price             NUMBER DEFAULT 0 NOT NULL,
    manufacturer_name VARCHAR2(30) NOT NULL,
    supply_date       DATE NOT NULL,
    supply_qty        NUMBER DEFAULT 0 NOT NULL,
    CONSTRAINT PK_PRODUCT PRIMARY KEY (product_id),
    CONSTRAINT FK_PRODUCT_MANUFACTURER FOREIGN KEY (manufacturer_name)
        REFERENCES MANUFACTURER(manufacturer_name),
    CONSTRAINT CHK_PRODUCT_STOCK CHECK (stock >= 0),
    CONSTRAINT CHK_PRODUCT_PRICE CHECK (price >= 0),
    CONSTRAINT CHK_PRODUCT_SUPPLYQTY CHECK (supply_qty >= 0)
);
/

-- 게시글 (참조: MEMBER_TB)
CREATE TABLE BOARD_TB (
    board_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title      VARCHAR2(100) NOT NULL,
    content    CLOB NOT NULL,
    write_date DATE DEFAULT SYSDATE NOT NULL,
    member_id  VARCHAR2(20) NOT NULL,
    CONSTRAINT FK_BOARD_MEMBER FOREIGN KEY (member_id)
        REFERENCES MEMBER_TB(member_id)
);
/

-- 주문 (참조: MEMBER_TB, PRODUCT_TB)
CREATE TABLE ORDERS_TB (
    order_id   VARCHAR2(20) NOT NULL,
    order_qty  NUMBER DEFAULT 1 NOT NULL,
    address    VARCHAR2(100) NOT NULL,
    order_date DATE DEFAULT SYSDATE NOT NULL,
    member_id  VARCHAR2(20) NOT NULL,
    product_id VARCHAR2(20) NOT NULL,
    CONSTRAINT PK_ORDERS PRIMARY KEY (order_id),
    CONSTRAINT FK_ORDERS_MEMBER FOREIGN KEY (member_id)
        REFERENCES MEMBER_TB(member_id),
    CONSTRAINT FK_ORDERS_PRODUCT FOREIGN KEY (product_id)
        REFERENCES PRODUCT_TB(product_id),
    CONSTRAINT CHK_ORDERS_QTY CHECK (order_qty >= 1)
);
/

